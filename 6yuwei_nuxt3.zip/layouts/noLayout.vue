<template>
  <slot />
</template>