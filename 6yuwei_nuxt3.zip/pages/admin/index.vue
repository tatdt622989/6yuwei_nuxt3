<template>
  <div>
    <h2 class="title">Dashboard</h2>
  </div>
</template>

<script>
</script>

<style lang="scss">
  .title {
    font-weight: 800;
    font-size: 32px;
    margin: 0;
  }
</style>
