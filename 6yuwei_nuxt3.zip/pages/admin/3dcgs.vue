<template>
  <div>
    <div class="titleWrap">
      <div class="text">
        <h2 class="title">3DCGs</h2>
        <p class="result" v-if="keyword">
          Search result: <span>{{ keyword ? `${keyword}` : "" }}</span>
        </p>
      </div>
      <AdminContentToolbar @open-editor-modal="openEditorModal" />
    </div>
    <div class="container-fluid">
      <div class="row">
        <div class="table-responsive">
          <div class="table-tool">
            <p class="total">Total: {{ total }}</p>
            <div v-if="selector.length > 0" class="right">
              <p class="selected">{{ selector.length }} item selected</p>
              <button
                class="delete btn"
                @click="openConfirmModal(deleteData, selector.join(','))"
              >
                <span class="material-symbols-outlined"> delete </span>
                Delete
              </button>
            </div>
          </div>
          <table class="table">
            <thead>
              <tr>
                <th scope="col" width="90">
                  <label class="selector">
                    <input
                      type="checkbox"
                      v-model="isAllSelected"
                      @change="selectAllItem"
                    />
                    <span class="bg"></span>
                    <span class="material-symbols-outlined mark"> check </span>
                  </label>
                </th>
                <th scope="col">Preview</th>
                <th scope="col">Title</th>
                <th scope="col">Category</th>
                <th scope="col">Off/On</th>
                <th scope="col">Home</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="website in threeDCGs" :key="website._id">
                <td>
                  <label class="selector">
                    <input
                      type="checkbox"
                      v-model="selector"
                      :value="website._id"
                    />
                    <span class="bg"></span>
                    <span class="material-symbols-outlined mark"> check </span>
                  </label>
                </td>
                <td>
                  <div
                    class="preview-box"
                    @click="openEditorModal('edit', website)"
                  >
                    <img
                      v-if="website.photos[0]"
                      :src="`${store.api}/admin/uploads/${website.photos[0].url}`"
                      :alt="website.title"
                    />
                    <span class="material-symbols-outlined">nature_people</span>
                  </div>
                </td>
                <td>{{ website.title }}</td>
                <td>{{ website.category }}</td>
                <td>
                  <label class="switch">
                    <input
                      type="checkbox"
                      v-model="website.visible"
                      @change="
                        updateVisibility(website._id ?? '', website.visible)
                      "
                    />
                    <span class="bg">
                      <span class="toggler" />
                    </span>
                  </label>
                </td>
                <td>
                  <label class="switch">
                    <input
                      type="checkbox"
                      v-model="website.homepage"
                      @change="
                        updateHomepage(website._id ?? '', website.homepage)
                      "
                    />
                    <span class="bg">
                      <span class="toggler" />
                    </span>
                  </label>
                </td>
                <td>
                  <div class="action-wrap">
                    <button
                      class="action copy"
                      @click="openConfirmModal(copyWebsite, website._id)"
                    >
                      <span class="material-symbols-outlined icon">
                        content_copy
                      </span>
                      <span class="text">Copy</span>
                    </button>
                    <button
                      class="action delete"
                      @click="openConfirmModal(deleteData, website._id)"
                    >
                      <span class="material-symbols-outlined icon">
                        delete
                      </span>
                      <span class="text">Delete</span>
                    </button>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <Pagination :total="totalPage" :current-page="currentPage" />
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { Editor, ThreeDCGs } from "~/types";
import { useStore } from "~/store";

interface UpdateData {
  _id: string;
  data: {
    [key: string]: string | boolean | Array<string>;
  };
}

useHead({
  title: "ThreeDCGs",
  titleTemplate: "%s - 6yuwei admin",
  meta: [
    {
      hid: "description",
      name: "description",
      content: "6yuwei - ThreeDCGs admin",
    },
  ],
});

// 需要驗證身份
definePageMeta({
  middleware: ["auth"],
});

const store = useStore();
const keyword = inject("keyword") as Ref<string>;

const editorModal = reactive({
  open: false,
  action: "add" as "add" | "edit",
  data: null as Editor | null,
});
const confirmModal = reactive({
  open: false,
  isConfirm: false,
  id: "",
  targetFunc: null as Function | null,
});
const threeDCGs = ref<Array<ThreeDCGs>>([]);
const selector = ref<Array<string>>([]);
const isAllSelected = ref(false);
const currentPage = ref(1);
const total = ref(0);
const totalPage = ref(1);
const category = ref([]);

const openEditorModal = (
  action: "add" | "edit",
  data: ThreeDCGs | null = null
) => {
  editorModal.open = true;
  editorModal.action = action;
  editorModal.data = data as Editor;
};

const openConfirmModal = (targetFunc: Function, id: string = "") => {
  confirmModal.isConfirm = false;
  confirmModal.open = true;
  confirmModal.targetFunc = targetFunc;
  confirmModal.id = id;
};

const onConfirm = async () => {
  confirmModal.isConfirm = true;
  confirmModal.targetFunc && confirmModal.targetFunc();
};

const closeEditorModal = async () => {
  editorModal.open = false;
};

const setEditorData = (data: ThreeDCGs) => {
  editorModal.data = data as Editor;
};

const selectAllItem = () => {
  if (threeDCGs.value) {
    if (!isAllSelected.value) {
      selector.value = [];
    } else {
      selector.value = threeDCGs.value.map((item) => item._id as string);
    }
  }
};

const copyWebsite = async () => {
  const id = confirmModal.id;
  const website = threeDCGs.value.find((item) => item._id === id);
  if (!website)
    return store.pushNotification({
      type: "error",
      message: "Website not found",
      timeout: 5000,
    });
  const api = `${store.api}/3dcgs/admin/list/`;
  const data = {
    title: website.title,
    description: website.description,
    externalLink: website.externalLink,
    textEditor: website.textEditor,
    category: website.category,
    visible: website.visible,
    photos: website.photos,
  };
  const res = await useFetch(api, {
    method: "POST",
    credentials: "include",
    body: JSON.stringify({
      data,
    }),
  });
  const error = res.error.value;
  if (error) {
    const status = error.status;
    status === 403 && navigateTo("/admin/login");
    store.pushNotification({
      type: "error",
      message: error.data,
      timeout: 5000,
    });
    return;
  }
  if (res.data.value) {
    store.pushNotification({
      type: "success",
      message: "Website copied",
      timeout: 5000,
    });
    getList();
  }
};

const getList = async () => {
  store.setLoading(true);
  const api = `${store.api}/3dcgs/admin/list/?page=${currentPage.value}&keyword=${keyword.value}`;
  const res = await useFetch(api, {
    method: "GET",
    credentials: "include",
  });
  const error = res.error.value;

  if (error) {
    const status = error.status;
    status === 403 && navigateTo("/admin/login");
    store.pushNotification({
      type: "error",
      message: 'Can not get threeDCGs list',
      timeout: 5000,
    });
    return store.setLoading(false);
  }

  const data = res.data.value as {
    msg: string;
    list: Array<ThreeDCGs>;
    total: number;
    totalPage: number;
  };
  if (data) {
    total.value = data.total;
    totalPage.value = data.totalPage;
    threeDCGs.value = data.list;
  }
  store.setLoading(false);
};

const getCategory = async () => {
  store.setLoading(true);
  const api = `${store.api}/3dcgs/admin/category/`;
  try {
    const res = await useFetch(api, {
      method: "GET",
      credentials: "include",
    });

    const error = res.error.value;
    if (error) {
      const status = error.status;
      status === 403 && navigateTo("/admin/login");
      store.pushNotification({
        type: "error",
        message: error.data,
        timeout: 5000,
      });
      return store.setLoading(false);
    }

    const data = res.data.value as {
      msg: string;
      list: Array<string>;
      category: [];
    };
    if (data) {
      category.value = data.category;
    }
  } catch (err) {
    store.pushNotification({
      type: "error",
      message: err as string,
      timeout: 5000,
    });
  }
  store.setLoading(false);
};

const deleteData = async () => {
  store.setLoading(true);
  const api = `${store.api}/3dcgs/admin/list/delete/`;
  const ids = confirmModal.id.split(",");
  const res = await useFetch(api, {
    method: "POST",
    credentials: "include",
    body: JSON.stringify({ ids }),
  });
  const error = res.error.value;
  if (error) {
    const status = error.status;
    status === 403 && navigateTo("/admin/login");
    store.pushNotification({
      type: "error",
      message: error.data,
      timeout: 5000,
    });
    return store.setLoading(false);
  }
  store.setLoading(false);
  await getList();
  editorModal.open = false;
  selector.value = [];
};

const updateData = async (data: UpdateData) => {
  store.setLoading(true);
  const api = `${store.api}/3dchs/admin/list`;
  const res = await useFetch(api, {
    method: "PUT",
    credentials: "include",
    body: JSON.stringify(data),
  });
  const error = res.error.value;
  const resData = res.data.value as { msg: string; threeDCGs: ThreeDCGs };
  if (error) {
    const status = error.status;
    status === 403 && navigateTo("/admin/login");
    store.pushNotification({
      type: "error",
      message: error.data,
      timeout: 5000,
    });
    return store.setLoading(false);
  }
  if (resData) {
    store.pushNotification({
      type: "success",
      message: resData.msg,
      timeout: 3000,
    });
  }
  store.setLoading(false);
  await getList();
  editorModal.open = false;
};

const updateVisibility = async (id: string, visible: boolean) => {
  updateData({
    _id: id,
    data: {
      visible,
    },
  });
};

const updateHomepage = async (id: string, homepage: boolean) => {
  updateData({
    _id: id,
    data: {
      homepage,
    },
  });
};

onMounted(async () => {
  store.setLoading(true);
  await getList();
  await getCategory();
  store.setLoading(false);
});

watch(
  () => selector.value,
  (val) => {
    const allId = threeDCGs.value.map((item) => item._id);
    const isChecked = val.length === allId.length;
    isAllSelected.value = isChecked;
  }
);

watch(
  () => keyword.value,
  () => {
    currentPage.value = 1;
    getList();
  }
);
</script>

<style lang="scss"></style>
